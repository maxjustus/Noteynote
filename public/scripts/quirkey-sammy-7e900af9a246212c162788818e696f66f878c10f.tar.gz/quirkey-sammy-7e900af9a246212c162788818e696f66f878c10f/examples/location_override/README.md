# Sammy

## Location Override Example

These two examples represent ways of overriding the default location ability to get and set the location from somewhere other then 

    window.location.hash
    
### index.html

Uses a text input as a 'location bar'. 

### data.html

Uses jQuery's $.data() accessor to get/set the location from within the applications element. (Submitted by CodeOfficer)
